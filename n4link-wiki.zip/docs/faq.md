# Perguntas Frequentes (FAQ)

Respostas para dúvidas comuns sobre o funcionamento da plataforma.