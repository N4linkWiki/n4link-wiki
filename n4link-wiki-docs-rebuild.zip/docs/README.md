<p align="center">
  <img src="/assets/logos/logo-n4link.png" alt="N4LINK" width="250" />
</p>

# Bem-vindo à Documentação N4LINK

A plataforma **N4LINK** é um iPaaS (Integration Platform as a Service) que conecta sistemas legados e modernos de forma ágil, segura e escalável.

---

## 🌐 Sistemas já integrados

<table>
  <tr>
    <td align="center"><img src="/assets/logos/vtex.png" width="100"/><br>VTEX</td>
    <td align="center"><img src="/assets/logos/sap.png" width="100"/><br>SAP</td>
    <td align="center"><img src="/assets/logos/totvs-novo.png" width="100"/><br>TOTVS</td>
    <td align="center"><img src="/assets/logos/salesforce.png" width="100"/><br>SALESFORCE</td>
  </tr>
  <tr>
    <td align="center"><img src="/assets/logos/rdstation.png" width="100"/><br>RD STATION</td>
    <td align="center"><img src="/assets/logos/pagseguro-novo.png" width="100"/><br>PAGSEGURO</td>
  </tr>
</table>

> Os demais logos serão adicionados em breve.
