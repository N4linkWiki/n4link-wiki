# Integração via Arquivos

Documentação em breve.